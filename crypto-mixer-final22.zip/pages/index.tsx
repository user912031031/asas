import CryptoMixer from "../components/CryptoMixer";

export default function Home() {
  return <CryptoMixer />;
}
